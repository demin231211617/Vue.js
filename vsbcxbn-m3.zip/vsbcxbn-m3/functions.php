<?php
    function format($num){
        return sprintf('%s<b class="rub">р</b>', number_format($num, 0, '', ' '));
    }

    function time_counter($expiration_date){
        date_format()
    }
?>