<?php
require_once ('helpers.php');
require_once ('data.php');

$main = include_template('main.php', [
        'categories' => $categories,
        'lots' => $lots
]);

$layout_content = include_template('layout.php',[
        'main' => $main,
    'user_name' => $user_name,
    'categories' => $categories,
    'title' => 'Главная',
    'is_auth' => $is_auth,
]);
print($layout_content);
?>