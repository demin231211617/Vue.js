import { defineComponent } from "../vendor/vue.esm-browser.js";
import MeetupCard from "./MeetupCard.js";

const fetchMeetups = () => fetch('./api/meetups.json').then((res) => res.json());

export default defineComponent({
    name: 'MeetupsList',

    props: {
        meetups: {
            type: Array,
            required: true,
        },
    },

    components: {
        MeetupCard,
    },

    template: `<ul class="meetups-list">
    <li v-for="meetup in meetups" :key="meetup.id" class="meetups-list__item">
      <a :href="\`/meetups/\${meetup.id}\`" class="meetups-list__item-link" tabindex="0">
        <meetup-card :meetup="meetup"/>
      </a>
    </li>
  </ul>`,
});