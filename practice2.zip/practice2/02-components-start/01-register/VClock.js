import { defineComponent } from './vendor/vue.esm-browser.js';

export default defineComponent({
    name: 'VClock',

    data() {
      return {
        time: '',
        intervalId: null,
        isWorking: true,
      };
    },

    created() {
      this.updateTime();
      this.intervalId = setInterval(() => {
        this.updateTime();
      }, 1000);
    },

    beforeUnmount() {
      clearInterval(this.intervalId);
    },

    template: `<div @click="isWorking = !isWorking">{{ time }}</div>`,

    methods: {
      updateTime() {
        if (this.isWorking) {
          this.time = new Date().toLocaleTimeString();
        }
      },
    },
  });