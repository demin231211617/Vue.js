<template>
  <div>Task 04-vue-cli/04-MeetupsCalendar + 10-slots/03-UiCalendarView</div>
</template>

<script>
// TODO: Task 04-vue-cli/04-MeetupsCalendar + 10-slots/03-UiCalendarView

export default {
  name: 'MeetupsCalendar',
};
</script>

<style scoped></style>
