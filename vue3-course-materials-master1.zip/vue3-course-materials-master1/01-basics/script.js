import {createApp, defineComponent} from './vendor/vue.esm-browser.js'

const fetchMeetups = () => fetch('./api/meetups.json').then((res) => res.json());

const App = defineComponent({
  name: 'App', 
  data(){
    return{
      hello: 'world',
      meetups: [],
      filter:{
        date: 'all',
        parcticipation: 'all',
        search: '',
      },
      view: 'list', //календарь
    };
  },

  mounred(){
    fetchMeetups().then((meetups) => {
      this.meetups = meetups;
    });
  },

  computed:{
    filteredMeetups(){
      const dateFilter = (meetup) =>
        this.filter.date === 'all' ||
        (this.filter.date === 'past' && new Date(meetup.date) <= new Date()) ||
        (this.filter.date === 'future' && new Date(meetup.date) > new Date());
        
        const participationFilter = (meetup) =>
        this.filter.participation === 'all' ||
        (this.filter.participation === 'organizing' && meetup.organizing) ||
        (this.filter.participation === 'attending' && meetup.attending);
        
        const searchFilter = (meetup) =>
        [meetup.title, meetup.description, meetup.place, meetup.organizer]
        .join(' ')
        .toLowerCase()
        .includes(this.filter.search.toLowerCase());
        
        return this.meetups.filter((meetup) => dateFilter(meetup) && participationFilter(meetup) && searchFilter(meetup));
    },
  },

  /*watch:{
    filter:{
      deep: true,
      immediate: true,
      handler(newValue, oldValue){
        this.filteredMeetups = this.filterMeetups();
      },
    },
    meetups:{
      deep: true,
        handler(){
          this.filteredMeetups = this.filterMeetups();
        },
    },
  },
*/

  methods:{
    filterMeetups() {
      const dateFilter = (meetup) =>
      this.filter.date === 'all' ||
      (this.filter.date === 'past' && new Date(meetup.date) <= new Date()) ||
      (this.filter.date === 'future' && new Date(meetup.date) > new Date());
      
      const participationFilter = (meetup) =>
      this.filter.participation === 'all' ||
      (this.filter.participation === 'organizing' && meetup.organizing) ||
      (this.filter.participation === 'attending' && meetup.attending);
      
      const searchFilter = (meetup) =>
      [meetup.title, meetup.description, meetup.place, meetup.organizer]
      .join(' ')
      .toLowerCase()
      .includes(this.filter.search.toLowerCase());
      
      return this.meetups.filter((meetup) => dateFilter(meetup) && participationFilter(meetup) && searchFilter(meetup));
    }, 
      
    formatAsLocalDate(timestamp){
      return new Date(timestamp).toLocaleString(navigator.language,{
        year: 'numeric',
        month: 'long',
        day: "numeric",
      });
    },

    formatAsIsoDate(timestamp){
      return new Date(timestamp).toISOString().split('T')[0];
    },
  },
});

const app = createApp(App);

const vm = app.mount('#app');

window.vm = vm;
