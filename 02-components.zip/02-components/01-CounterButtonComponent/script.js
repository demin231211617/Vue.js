import { createApp } from './vendor/vue.esm-browser.js';
import App from './App.js';



createApp(App).mount('#app');
