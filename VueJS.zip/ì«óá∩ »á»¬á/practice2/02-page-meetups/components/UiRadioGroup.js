import { defineComponent } from '../vendor/vue.esm-browser.js';
export default defineComponent({
    name: 'UiRadioGroup',

    props: {
        // description
        options: {
            type: Array,
            required: true,
        },
        value: {
            type: String,
        },
        name: {
            type: String,
            required: true,
        },
    },
    emits:['update:modelValue'],
    template: `
    <div class="radio-group">
        <div v-for="option in options" class="radio-group__button">
          <input
            :id="\`radio-buttons_\${name}_\${option.value}\`"
            class="radio-group__input"
            type="radio"
            :name="name"
            value="option.value"
            :checked="value === option.value"
            @change="$emit('update:modelValue', option.value)"
          />
          <label for="radio-buttons_date_all" class="radio-group__label">{{option.text}}</label>
        </div>
    </div>`,
});
